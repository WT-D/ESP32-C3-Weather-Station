#ifndef _OLED_DRIVER_
#define _OLED_DRIVER_

#include <HardwareSerial.h>
#include <Arduino.h>
#include <SPI.h>
#include <Wire.h>
#include <pgmspace.h>

#define UBYTE   uint8_t
#define UWORD   uint16_t
#define UDOUBLE uint32_t

#define OLED_CS 10
#define OLED_CS_0     digitalWrite(OLED_CS, LOW)
#define OLED_CS_1     digitalWrite(OLED_CS, HIGH)

#define OLED_RST 5
#define OLED_RST_0    digitalWrite(OLED_RST, LOW)
#define OLED_RST_1    digitalWrite(OLED_RST, HIGH)

#define OLED_DC 4
#define OLED_DC_0     digitalWrite(OLED_DC, LOW)
#define OLED_DC_1     digitalWrite(OLED_DC, HIGH)

#define OLED_SCK 6
#define OLED_MOSI 7

void SPI_Init(void);
void SPI_Write_Byte(uint8_t DATA);
void OLED_Write_CMD(uint8_t cmd);
void OLED_Write_DATA(uint8_t dat);
void OLED_ColorTurn(uint8_t i);
void OLED_DisplayTurn(uint8_t i);
void OLED_Set_Pos(uint8_t x, uint8_t y);
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Clear(void);
void OLED_Init(void);

#endif
