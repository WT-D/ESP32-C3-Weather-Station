#ifndef SHT40_H
#define SHT40_H

#include <Arduino.h>

// 初始化 SHT40 传感器
void SHT40_Init();

// 读取 SHT40 传感器数据
bool readSHT40(float &temperature, float &humidity);

#endif
