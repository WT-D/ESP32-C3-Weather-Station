#include "SHT40.h"
#include <Wire.h>

// SHT40 I2C 地址
#define SHT40_I2C_ADDR 0x46

// 定义 SDA 和 SCL 引脚
#define SDA_PIN 0
#define SCL_PIN 1

// 初始化 SHT40 传感器
void SHT40_Init() {
    Wire.begin(SDA_PIN, SCL_PIN);
    Serial.println("SHT40 初始化完成!");
}

// 发送测量命令并读取数据
bool readSHT40(float &temperature, float &humidity) {
    Wire.beginTransmission(SHT40_I2C_ADDR);
    Wire.write(0xFD); // 触发测量命令（高精度）
    if (Wire.endTransmission() != 0) {
        Serial.println("SHT40 传感器无响应!");
        return false;
    }

    delay(10); // 等待测量完成

    // 读取 6 字节数据
    Wire.requestFrom(SHT40_I2C_ADDR, 6);
    if (Wire.available() != 6) {
        Serial.println("SHT40 数据读取失败!");
        return false;
    }

    uint8_t data[6];
    for (int i = 0; i < 6; i++) {
        data[i] = Wire.read();
    }

    // 解析温度数据
    uint16_t rawTemp = (data[0] << 8) | data[1];
    temperature = -45.0f + (175.0f * ((float)rawTemp / 65535.0f));

    // 解析湿度数据
    uint16_t rawHumidity = (data[3] << 8) | data[4];
    humidity = (100.0f * ((float)rawHumidity / 65535.0f));

    return true;
}
