#include "oled.h"
#include "font.h"

#define PAGE_ADDR_CMD       0xB0
#define COL_LOW_MASK        0x0F
#define COL_HIGH_OFFSET     4
#define OLED_PAGE_HEIGHT    8

static void oled_set_pos(uint8_t x, uint8_t y_page);

static void oled_set_pos(uint8_t x, uint8_t y_page) {
    OLED_Write_CMD(PAGE_ADDR_CMD + y_page);
    OLED_Write_CMD(x & COL_LOW_MASK);
    OLED_Write_CMD(0x10 | (x >> COL_HIGH_OFFSET));
}

void OLED_ShowChar(uint8_t x, uint8_t y_pixel, const uint8_t chr) {
    uint8_t page = y_pixel / OLED_PAGE_HEIGHT;     
    uint8_t bit_offset = y_pixel % OLED_PAGE_HEIGHT; 
    const uint8_t *font_ptr = &asc2_0806[chr - ' '][0];

    for (uint8_t i = 0; i < 6; i++) {  
        uint8_t data = font_ptr[i];

        oled_set_pos(x + i, page);
        OLED_Write_DATA(data << bit_offset);

        if (bit_offset > 0 && (page + 1) < 8) {
            oled_set_pos(x + i, page + 1);
            OLED_Write_DATA(data >> (OLED_PAGE_HEIGHT - bit_offset));
        }
    }
}

void OLED_ShowString(uint8_t x, uint8_t y_pixel, const char *str) {
    while (*str) {
        OLED_ShowChar(x, y_pixel, *str);
        x += 6; 
        if (x >= 128 - 6) break;
        str++;
    }
}

void OLED_ShowNum(uint8_t x, uint8_t y_pixel, int32_t num) {
    char str[12];  
    snprintf(str, sizeof(str), "%d", num);
    OLED_ShowString(x, y_pixel, str);
}

void OLED_DrawBMP(uint8_t x, uint8_t y_page, const uint8_t *bmp)
{
    uint8_t width = pgm_read_byte(bmp);
    uint8_t height = pgm_read_byte(bmp + 1);
    const uint8_t *bmp_data = bmp + 2;

    if((x + width) > 128 || 
       (y_page + (height/OLED_PAGE_HEIGHT)) > 7) {
        return;
    }

    uint8_t total_pages = (height / OLED_PAGE_HEIGHT) + 
                         ((height % OLED_PAGE_HEIGHT) ? 1 : 0);
    uint16_t data_index = 0;

    for(uint8_t page = 0; page < total_pages; page++) {
        oled_set_pos(x, y_page + page);
        for(uint8_t col = 0; col < width; col++) {
            OLED_Write_DATA(pgm_read_byte(bmp_data + data_index++));
        }
    }
}


