#ifndef _OLED_
#define _OLED_

#include "oled_driver.h"

#define OLED_PAGE_HEIGHT    8      
#define FONT_8PX_HEIGHT     8
#define FONT_16PX_HEIGHT    16
#define FONT_8PX_WIDTH      6
#define FONT_16PX_WIDTH     8

void OLED_ShowChar(uint8_t x, uint8_t y_pixel, const uint8_t chr);
void OLED_ShowString(uint8_t x, uint8_t y_pixel, const char *str);
void OLED_ShowNum(uint8_t x, uint8_t y_pixel, int32_t num);
void OLED_DrawBMP(uint8_t x, uint8_t y_page, const uint8_t *bmp);

#endif


