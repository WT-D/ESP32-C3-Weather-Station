#include "oled_driver.h"
#include <stdio.h>

void SPI_Init(void)
{
  pinMode(OLED_CS, OUTPUT);
  pinMode(OLED_RST, OUTPUT);
  pinMode(OLED_DC, OUTPUT);

  SPI.setDataMode(SPI_MODE3);
  SPI.setBitOrder(MSBFIRST);
  SPI.setClockDivider(SPI_CLOCK_DIV2);
  SPI.begin(OLED_SCK, -1, OLED_MOSI, OLED_CS);
}

void SPI_Write_Byte(uint8_t DATA)
{
  SPI.transfer(DATA);
}

void OLED_Write_CMD(uint8_t cmd)
{
  OLED_DC_0;
  OLED_CS_0;
  SPI_Write_Byte(cmd);
  OLED_CS_1;
}

void OLED_Write_DATA(uint8_t dat)
{
  OLED_DC_1;
  OLED_CS_0;
  SPI_Write_Byte(dat);
  OLED_CS_1;
}

static void OLED_Reset(void)
{
  OLED_RST_1;
  delay(100);
  OLED_RST_0;
  delay(100);
  OLED_RST_1;
  delay(100);
}

//反显函数
void OLED_ColorTurn(uint8_t i)
{
  if(!i) OLED_Write_CMD(0xA6);//正常显示
  else  OLED_Write_CMD(0xA7);//反色显示
}

//屏幕旋转180度
void OLED_DisplayTurn(uint8_t i)
{
  if(i==0)
    {
      OLED_Write_CMD(0xC8);//正常显示
      OLED_Write_CMD(0xA1);
    }
else
    {
      OLED_Write_CMD(0xC0);//反转显示
      OLED_Write_CMD(0xA0);
    }
}

void OLED_Set_Pos(uint8_t x, uint8_t y) 
{ 
  OLED_Write_CMD(0xb0+y);
  OLED_Write_CMD(((x&0xf0)>>4)|0x10);
  OLED_Write_CMD((x&0x0f));
}       
//开启OLED显示    
void OLED_Display_On(void)
{
  OLED_Write_CMD(0X8D);  //SET DCDC命令
  OLED_Write_CMD(0X14);  //DCDC ON
  OLED_Write_CMD(0XAF);  //DISPLAY ON
}
//关闭OLED显示     
void OLED_Display_Off(void)
{
  OLED_Write_CMD(0X8D);  //SET DCDC命令
  OLED_Write_CMD(0X10);  //DCDC OFF
  OLED_Write_CMD(0XAE);  //DISPLAY OFF
}            
//清屏函数,清完屏,整个屏幕是黑色的!和没点亮一样!!!   
void OLED_Clear(void)  
{  
  uint8_t i,n;       
  for(i=0;i<8;i++)  
  {  
    OLED_Write_CMD (0xb0+i);    //设置页地址（0~7）
    OLED_Write_CMD (0x00);      //设置显示位置—列低地址
    OLED_Write_CMD (0x10);      //设置显示位置—列高地址   
    for(n=0;n<128;n++)OLED_Write_DATA(0); 
  } //更新显示
}


void OLED_Init(void)
{
  OLED_Reset();
  OLED_Write_CMD(0xAE);//--turn off oled panel
  OLED_Write_CMD(0xFD);
  OLED_Write_CMD(0x12);
  OLED_Write_CMD(0xd5);//--set display clock divide ratio/oscillator frequency
  OLED_Write_CMD(0xA0);
  OLED_Write_CMD(0xA8);//--set multiplex ratio(1 to 64)
  OLED_Write_CMD(0x3f);//--1/64 duty
  OLED_Write_CMD(0xD3);//-set display offset Shift Mapping RAM Counter (0x00~0x3F)
  OLED_Write_CMD(0x00);//-not offset
  OLED_Write_CMD(0x40);//--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
  OLED_Write_CMD(0xA1);//--Set SEG/Column Mapping     0xa0左右反置 0xa1正常
  OLED_Write_CMD(0xC8);//Set COM/Row Scan Direction   0xc0上下反置 0xc8正常
  OLED_Write_CMD(0xDA);//--set com pins hardware configuration
  OLED_Write_CMD(0x12);
  OLED_Write_CMD(0x81);//--set contrast control register
  OLED_Write_CMD(0xFF);// Set SEG Output Current Brightness
  OLED_Write_CMD(0xD9);//--set pre-charge period
  OLED_Write_CMD(0x25);//Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
  OLED_Write_CMD(0xDB);//--set vcomh
  OLED_Write_CMD(0x34);//Set VCOM Deselect Level
  OLED_Write_CMD(0xA4);// Disable Entire Display On (0xa4/0xa5)
  OLED_Write_CMD(0xA6);// Disable Inverse Display On (0xa6/a7)
  OLED_Clear();
  OLED_Write_CMD(0xAF);
}







